//
//  ViewController.swift
//  Calculator
//
//  Created by 郭梓琳 on 2022/3/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var processLabel: UILabel!
    @IBOutlet var resultLabel: UILabel!
    @IBOutlet var clearButton: UIButton!
    
    var firstNumber = Double()
    var secondNumber = Double()
    var lastNumber = String()
    var isTypingNumber: Bool = false
    var operationTapped = String()
    var isOperationTapped: Bool = false
    var isEqualPressed: Bool = false
    var isClearPressed: Bool = false
    var previousOperator = String()
    var midAnswer = Double()
    let tagList = ["+","－","×","÷"]
    
    @IBAction func numberButton(_ sender: UIButton) {
        
        if(isEqualPressed) {
            processLabel.text = ""
        }
        processLabel.text! += String(sender.tag)

        if(!isTypingNumber) {
            lastNumber = String(Double(sender.tag))
        }
        else {
            lastNumber = String(Double(lastNumber)! * 10 + Double(sender.tag))
        }
        resultLabel.text = String(lastNumber)
        isTypingNumber = true
        isEqualPressed = false
        clearButton.setTitle("C", for: .normal)
        isClearPressed = false
    }
    
    @IBAction func operation(_ sender: UIButton) {
        if(isEqualPressed) {
            processLabel.text = ""
        }
        operationTapped = tagList[sender.tag]
        
        if(!isOperationTapped) {
            if(processLabel.text == "") {
                processLabel.text! += "0"
            }
            firstNumber = Double(lastNumber)!
            lastNumber = "0"
            processLabel.text! += operationTapped
        }
        else {
            if(isTypingNumber) {
                if(operationTapped == "×" || previousOperator == "÷") {
                    if(firstNumber != 0) {
                        secondNumber = Double(lastNumber)!
                    }
                    else {
                        firstNumber = Double(lastNumber)!
                    }
                }
                else {
                    if(previousOperator == "+") {
                        midAnswer = firstNumber + Double(lastNumber)!
                    }
                    else if(previousOperator == "－") {
                        midAnswer = firstNumber - Double(lastNumber)!
                    }
                    else if(previousOperator == "×") {
                        if(secondNumber != 0) {
                            midAnswer = secondNumber * Double(lastNumber)!
                        }
                        else {
                            midAnswer = firstNumber * Double(lastNumber)!
                        }
                    }
                    else if(previousOperator == "÷") {
                        if lastNumber == "0" {
                            midAnswer = 0
                        }
                        else {
                            if(secondNumber != 0) {
                                midAnswer = secondNumber / Double(lastNumber)!
                            }
                            else {
                                midAnswer = firstNumber / Double(lastNumber)!
                            }
                        }
                    }
                    firstNumber = midAnswer
                }
                lastNumber = "0"
                processLabel.text! += operationTapped
            }
            processLabel.text?.removeLast()
            processLabel.text! += operationTapped
        }
        previousOperator = operationTapped
        isTypingNumber = false
        isOperationTapped = true
        isEqualPressed = false
        clearButton.setTitle("C", for: .normal)
        isClearPressed = false
        print(firstNumber, secondNumber, lastNumber, midAnswer)
    }
    
    @IBAction func equal(_ sender: UIButton) {
        if(isEqualPressed) {
            return
        }
        
        var result: Double = 0
        secondNumber = Double(lastNumber)!

        if(operationTapped == "+") {
            result = firstNumber + secondNumber
        }
        else if(operationTapped == "－") {
            result = firstNumber - secondNumber
        }
        else if(operationTapped == "×") {
            result = firstNumber * secondNumber
        }
        else if(operationTapped == "÷") {
            if(secondNumber == 0) {
                result = 0
            }
            else {
                result = firstNumber / secondNumber
            }
        }
        processLabel.text! += "="
        
        resultLabel.text = String(result)
        firstNumber = 0
        secondNumber = 0
        midAnswer = 0
        lastNumber = "0"
        isTypingNumber = false
        isOperationTapped = false
        isEqualPressed = true
        isClearPressed = true
    }
    
    @IBAction func clearAll(_ sender: UIButton) {
        if(isClearPressed) {    // AC
            firstNumber = 0
            secondNumber = 0
            processLabel.text = ""
            resultLabel.text = "0"
            isOperationTapped = false
            isEqualPressed = false
        }
        else {
            resultLabel.text = "0"
            while (processLabel.text?.last?.isNumber == true){
                processLabel.text?.removeLast()
            }
            if(processLabel.text?.last == ".") {    // remove decimal point
                processLabel.text?.removeLast()
                while (processLabel.text?.last?.isNumber == true){
                    processLabel.text?.removeLast()
                }
            }
            if(Double(lastNumber)! < 0){   // remove negetive sign
                processLabel.text?.removeLast()
            }
            isClearPressed = true
        }
        sender.setTitle("AC", for: .normal)
        lastNumber = "0"
        isTypingNumber = false
    }
    
    @IBAction func changeSign(_ sender: UIButton) {
        if(isEqualPressed) {
            processLabel.text = ""
            lastNumber = resultLabel.text!
            isEqualPressed = false
        }
        else {
            while (processLabel.text?.last?.isNumber == true){
                processLabel.text?.removeLast()
            }
            if(processLabel.text?.last == ".") {    // remove decimal point
                processLabel.text?.removeLast()
                while (processLabel.text?.last?.isNumber == true){
                    processLabel.text?.removeLast()
                }
            }
            if(Double(lastNumber)! < 0) {    // remove negetive sign
                processLabel.text?.removeLast()
            }
        }
        
        lastNumber = String(Double(lastNumber)! * -1)
        resultLabel.text = lastNumber
        processLabel.text! += lastNumber
        // remove decimal number and point
        while (processLabel.text?.last?.isNumber == true){
            processLabel.text?.removeLast()
        }
        processLabel.text?.removeLast()
    }
    
    
    @IBAction func percent(_ sender: UIButton) {
        lastNumber = String(Double(lastNumber)! * 0.01)
        resultLabel.text = String(lastNumber)
        while (processLabel.text?.last?.isNumber == true){
            processLabel.text?.removeLast()
        }
        if(processLabel.text?.last == ".") {    // remove decimal point
            processLabel.text?.removeLast()
            while (processLabel.text?.last?.isNumber == true){
                processLabel.text?.removeLast()
            }
        }
        if(Double(lastNumber)! < 0) {    // remove negetive sign
            processLabel.text?.removeLast()
        }
        processLabel.text! += String(lastNumber)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        processLabel.adjustsFontSizeToFitWidth = true
        resultLabel.adjustsFontSizeToFitWidth = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
